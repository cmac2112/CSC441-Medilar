export interface DepartmentDto {
  id?: number;
  name: string;
  description: string;
  imageUrl?: string;
}
