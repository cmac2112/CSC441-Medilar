export interface CustomerDto {
  key?: string;
  name: string;
  job: string;
  email: string;
  phoneNumber: string;
  address: string;
  active: boolean;
}
