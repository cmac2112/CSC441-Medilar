export interface StaffDto {
  id?: number;
  name: string;
  job: string;
  email: string;
  phoneNumber: string;
  address: string;
  active: boolean;
}
